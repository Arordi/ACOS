# ACOS Architecture

## Control flow

User Intent
→ Scope
→ Constraints
→ Plan
→ Router
→ Execution
→ Output Diff
→ Quality Gate
→ Approval
→ Result

## Core engines

- Intent
- Planning
- Scope Lock
- Preservation
- Mask
- Change Impact
- Continuity
- Glossary
- Translation Memory
- Localization
- Quality
- Version
- Checkpoint
- Cache
- Export/Import
- Transfer
- Cost/Budget
- Payment
- Rights/License
- Discovery/Benchmark
- Human Review

## Portability

The `.acos.zip` package is the first portable project format. It is intentionally provider-neutral: project metadata, glossary, translation memory, constraints and assets can move between ACOS installations.

## AI adapters

The MVP deliberately does not hard-code one AI vendor. Production adapters should implement a common interface and register:

- capability
- model
- provider
- version
- license
- cost
- latency
- quality benchmark
- hardware requirements
- privacy mode

## Production upgrade

The starter SQLite database is appropriate for development. Production should use PostgreSQL + Redis + object storage + worker/GPU scheduler.
