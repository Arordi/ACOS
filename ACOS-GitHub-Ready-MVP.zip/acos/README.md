# ACOS — AI Creative Operating System

ACOS is a GitHub-ready, modular foundation for an AI Creative Operating System.

## What works in this MVP

- Project creation and management
- File upload with resumable-friendly asset storage structure
- Glossary-first terminology workflow
- Translation memory records
- Precision edit scope + preservation constraints
- Job queue/status tracking
- Basic quality gates
- Output-diff safety checks
- Project export/import package (`.acos.zip`)
- One-click download of generated project packages
- Browser UI served by the same FastAPI application
- SQLite database for the starter version
- Docker support
- Automated API tests

## Important

This repository is a **working MVP foundation**, not a claim that every advanced AI model is bundled locally.

AI providers are isolated behind adapters. You can later connect local/open-source models or external APIs without changing the core project model.

## Run locally

Python 3.11+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open:

`http://127.0.0.1:8000`

API documentation:

`http://127.0.0.1:8000/docs`

## Run with Docker

```bash
docker compose up --build
```

Then open:

`http://127.0.0.1:8000`

## Project package

ACOS exports projects as:

`<project-name>.acos.zip`

The package contains project metadata, glossary, translation memory, workflow data, and assets.

This is designed so a project can be moved between a phone, computer, backup, or another ACOS installation.

## Architecture

```text
User
  |
Web UI
  |
FastAPI API
  |
Creative Control Plane
  |
+---------------------------+
| Intent / Scope / Policy   |
| Memory / Approval / Audit |
+---------------------------+
  |
Workflow Engine
  |
+------------------------------+
| Glossary / Translation       |
| Precision Edit / Mask        |
| Preservation / Diff         |
| Quality / Version / Export  |
+------------------------------+
  |
Job Queue / Workers
  |
Model + Tool + Provider Router
  |
Local/Open-source/API adapters
```

## Safety principle

The core editing rule is:

**Intent → Scope → Constraint → Execution → Diff → Quality Gate → Approval**

If a user says "change only this", the system records that as a preservation constraint rather than relying only on an AI prompt.

## Next production steps

1. Add authentication and organization roles.
2. Replace SQLite with PostgreSQL for production.
3. Add Redis/queue workers and GPU scheduling.
4. Add object storage (S3-compatible).
5. Add real model/tool/provider adapters.
6. Add model sandbox + benchmark + license checks.
7. Add payment providers and immutable financial ledger.
8. Add real video scene/shot detection, masks, tracking, dubbing and lip-sync pipelines.
9. Add encrypted secrets and production observability.
10. Add mobile/PWA packaging and secure device transfer.
