from fastapi.testclient import TestClient
from app.main import app
from app.db import init_db

init_db()
client = TestClient(app)

def test_health():
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["ok"] is True

def test_create_project_and_glossary():
    p = client.post("/api/projects", json={"name":"Test Film"}).json()
    assert p["name"] == "Test Film"

    t = client.post(
        f"/api/projects/{p['id']}/glossary",
        json={"source":"Blackthorn","target":"Բլեքթորն","locked":True}
    )
    assert t.status_code == 200

    c = client.post(
        f"/api/projects/{p['id']}/glossary/check",
        json={"text":"Blackthorn is here."}
    )
    assert c.status_code == 200
    assert len(c.json()["matched_terms"]) == 1
