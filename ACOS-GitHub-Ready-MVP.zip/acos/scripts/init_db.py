from app.db import init_db
init_db()
print("ACOS database initialized.")
