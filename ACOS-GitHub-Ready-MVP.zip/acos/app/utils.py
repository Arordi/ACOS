from datetime import datetime, timezone
import hashlib
import json
import uuid

def now():
    return datetime.now(timezone.utc).isoformat()

def uid(prefix=""):
    value = str(uuid.uuid4())
    return f"{prefix}{value}" if prefix else value

def sha256_bytes(data: bytes):
    return hashlib.sha256(data).hexdigest()

def json_dumps(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
