from pathlib import Path
import shutil
from ..config import STORAGE_PATH

def project_dir(project_id: str) -> Path:
    path = STORAGE_PATH / "projects" / project_id
    path.mkdir(parents=True, exist_ok=True)
    return path

def asset_path(project_id: str, asset_id: str, filename: str) -> Path:
    safe = Path(filename).name
    folder = project_dir(project_id) / "assets"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / f"{asset_id}__{safe}"

def delete_project_storage(project_id: str):
    path = STORAGE_PATH / "projects" / project_id
    if path.exists():
        shutil.rmtree(path)
