from pathlib import Path
import json
import zipfile
from ..db import fetch_one, fetch_all
from ..services.storage import project_dir
from ..utils import now

def export_project(project_id: str, destination: Path):
    project = fetch_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if not project:
        raise ValueError("Project not found")

    assets = fetch_all("SELECT * FROM assets WHERE project_id=?", (project_id,))
    glossary = fetch_all("SELECT * FROM glossary_terms WHERE project_id=?", (project_id,))
    memory = fetch_all("SELECT * FROM translation_memory WHERE project_id=?", (project_id,))
    constraints = fetch_all("SELECT * FROM constraints WHERE project_id=?", (project_id,))

    manifest = {
        "format": "acos-project",
        "version": 1,
        "exported_at": now(),
        "project": project,
        "assets": assets,
        "glossary": glossary,
        "translation_memory": memory,
        "constraints": constraints,
    }

    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("project.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        base = project_dir(project_id)
        if base.exists():
            for file in base.rglob("*"):
                if file.is_file():
                    z.write(file, file.relative_to(base))

    return destination
