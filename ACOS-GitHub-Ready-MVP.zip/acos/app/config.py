import os
from pathlib import Path

APP_NAME = os.getenv("ACOS_APP_NAME", "ACOS")
DATABASE_PATH = Path(os.getenv("ACOS_DATABASE_PATH", "data/acos.db"))
STORAGE_PATH = Path(os.getenv("ACOS_STORAGE_PATH", "data/storage"))
MAX_UPLOAD_MB = int(os.getenv("ACOS_MAX_UPLOAD_MB", "2048"))

DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
STORAGE_PATH.mkdir(parents=True, exist_ok=True)
