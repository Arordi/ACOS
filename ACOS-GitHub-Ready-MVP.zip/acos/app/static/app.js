let currentProject = null;

async function api(url, options={}) {
  const r = await fetch(url, options);
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

async function loadProjects() {
  const projects = await api('/api/projects');
  const box = document.getElementById('projects');
  box.innerHTML = '';
  for (const p of projects) {
    const div = document.createElement('div');
    div.className = 'project';
    div.innerHTML = `<strong>${escapeHtml(p.name)}</strong><span>${escapeHtml(p.description || '')}</span><button>Բացել</button>`;
    div.querySelector('button').onclick = () => openProject(p);
    box.appendChild(div);
  }
}

async function createProject() {
  const name = document.getElementById('projectName').value.trim();
  const description = document.getElementById('projectDescription').value.trim();
  if (!name) return alert('Գրիր նախագծի անունը');
  const p = await api('/api/projects', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({name, description})
  });
  openProject(p);
  loadProjects();
}

async function openProject(p) {
  currentProject = p;
  document.getElementById('workspace').hidden = false;
  document.getElementById('workspaceTitle').textContent = p.name;
  document.getElementById('exportLink').href = `/api/projects/${p.id}/export`;
  await refreshWorkspace();
}

async function refreshWorkspace() {
  const assets = await api(`/api/projects/${currentProject.id}/assets`);
  document.getElementById('assets').innerHTML = assets.map(a =>
    `<div>${escapeHtml(a.filename)} — ${a.size} bytes — ${a.sha256.slice(0,12)}...</div>`).join('');

  const glossary = await api(`/api/projects/${currentProject.id}/glossary`);
  document.getElementById('glossary').innerHTML = glossary.map(t =>
    `<div>${escapeHtml(t.source)} → <b>${escapeHtml(t.target)}</b> ${t.locked ? '🔒' : ''}</div>`).join('');
}

async function uploadAsset() {
  if (!currentProject) return;
  const file = document.getElementById('assetFile').files[0];
  if (!file) return alert('Ընտրիր ֆայլ');
  const fd = new FormData();
  fd.append('file', file);
  await api(`/api/projects/${currentProject.id}/assets`, {method:'POST', body:fd});
  refreshWorkspace();
}

async function addGlossary() {
  const source = document.getElementById('sourceTerm').value.trim();
  const target = document.getElementById('targetTerm').value.trim();
  if (!source || !target) return alert('Լրացրու երկու դաշտը');
  await api(`/api/projects/${currentProject.id}/glossary`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({source,target,locked:true})
  });
  refreshWorkspace();
}

async function checkGlossary() {
  const text = document.getElementById('checkText').value;
  const result = await api(`/api/projects/${currentProject.id}/glossary/check`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({text})
  });
  document.getElementById('checkResult').textContent = JSON.stringify(result,null,2);
}

async function createEdit() {
  const preserve = document.getElementById('preserve').value.split(',').map(x=>x.trim()).filter(Boolean);
  const body = {
    scope_type: document.getElementById('scopeType').value,
    scope_value: document.getElementById('scopeValue').value,
    object_id: document.getElementById('objectId').value,
    property_name: document.getElementById('propertyName').value,
    change_value: document.getElementById('changeValue').value,
    preserve
  };
  const result = await api(`/api/projects/${currentProject.id}/edits`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify(body)
  });
  alert(`Պահպանված է՝ ${result.id}`);
}

async function runTranslation() {
  const text = document.getElementById('translationText').value;
  const job = await api(`/api/projects/${currentProject.id}/jobs/translation`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({text})
  });
  document.getElementById('jobResult').textContent = JSON.stringify(job,null,2);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

loadProjects().catch(console.error);
