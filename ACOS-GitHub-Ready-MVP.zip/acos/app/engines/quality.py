def quality_gate(metrics: dict, thresholds: dict | None = None):
    thresholds = thresholds or {
        "translation": 0.80,
        "scope_preservation": 1.00,
        "technical": 0.90,
    }
    failures = []
    for key, minimum in thresholds.items():
        value = float(metrics.get(key, 0))
        if value < minimum:
            failures.append({"metric": key, "value": value, "minimum": minimum})
    return {"passed": not failures, "failures": failures, "metrics": metrics}
