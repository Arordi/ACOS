from .glossary import terminology_check
from .quality import quality_gate

def build_translation_plan(project_id: str, text: str):
    glossary = terminology_check(project_id, text)
    return {
        "steps": [
            "transcript",
            "glossary_check",
            "translation_memory_check",
            "translation",
            "context_review",
            "quality_gate",
        ],
        "glossary": glossary,
        "approval_required": glossary["requires_review"],
    }

def run_mock_translation(project_id: str, text: str):
    # Safe MVP adapter: no claim of real AI translation.
    plan = build_translation_plan(project_id, text)
    result = {
        "source": text,
        "target": text,
        "provider": "local-mock",
        "note": "Connect a real translation adapter in production.",
    }
    gate = quality_gate({
        "translation": 1.0,
        "scope_preservation": 1.0,
        "technical": 1.0,
    })
    return {"plan": plan, "result": result, "quality": gate}
