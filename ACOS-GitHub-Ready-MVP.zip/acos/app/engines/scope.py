from dataclasses import dataclass, field

@dataclass
class EditScope:
    scope_type: str
    scope_value: str
    object_id: str = ""
    property_name: str = ""
    change_value: str = ""
    preserve: list[str] = field(default_factory=list)

def validate_scope(scope: EditScope):
    allowed = {"frame", "time_range", "shot", "scene", "object", "project"}
    if scope.scope_type not in allowed:
        raise ValueError(f"Unsupported scope_type: {scope.scope_type}")
    if not scope.scope_value.strip():
        raise ValueError("scope_value is required")
    return True
