from ..db import fetch_all

def terminology_check(project_id: str, text: str):
    terms = fetch_all(
        "SELECT source, target, term_type, locked FROM glossary_terms WHERE project_id=?",
        (project_id,),
    )
    matches = []
    lower = text.lower()
    for term in terms:
        if term["source"].lower() in lower:
            matches.append(term)
    return {
        "matched_terms": matches,
        "requires_review": any(not m["locked"] for m in matches),
    }
