def verify_scope(original: dict, result: dict, locked_fields: list[str]):
    changed = []
    unexpected = []
    for key, value in result.items():
        if original.get(key) != value:
            changed.append(key)
            if key in locked_fields:
                unexpected.append(key)
    return {
        "changed_fields": changed,
        "unexpected_changes": unexpected,
        "passed": len(unexpected) == 0,
    }
