from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from .config import APP_NAME
from .db import init_db
from .api.projects import router as projects_router
from .api.assets import router as assets_router
from .api.glossary import router as glossary_router
from .api.edits import router as edits_router
from .api.jobs import router as jobs_router
from .api.export import router as export_router

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(
    title=APP_NAME,
    version="0.1.0",
    description="ACOS — AI Creative Operating System",
)

@app.on_event("startup")
def startup():
    init_db()

@app.get("/api/health")
def health():
    return {"ok": True, "name": APP_NAME, "version": "0.1.0"}

app.include_router(projects_router)
app.include_router(assets_router)
app.include_router(glossary_router)
app.include_router(edits_router)
app.include_router(jobs_router)
app.include_router(export_router)

app.mount("/", StaticFiles(directory=str(BASE_DIR / "static"), html=True), name="static")
