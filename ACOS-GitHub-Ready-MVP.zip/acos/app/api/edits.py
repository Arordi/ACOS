from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from ..db import execute, fetch_one, fetch_all
from ..engines.scope import EditScope, validate_scope
from ..utils import now, uid

router = APIRouter(prefix="/api/projects", tags=["precision-edit"])

class EditCreate(BaseModel):
    scope_type: str
    scope_value: str
    object_id: str = ""
    property_name: str = ""
    change_value: str = ""
    preserve: list[str] = Field(default_factory=list)

@router.post("/{project_id}/edits")
def create_edit(project_id: str, data: EditCreate):
    if not fetch_one("SELECT id FROM projects WHERE id=?", (project_id,)):
        raise HTTPException(404, "Project not found")
    scope = EditScope(**data.model_dump())
    validate_scope(scope)
    edit_id = uid("edit_")
    execute(
        "INSERT INTO constraints(id,project_id,scope_type,scope_value,object_id,property_name,change_value,preserve_json,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
        (edit_id, project_id, scope.scope_type, scope.scope_value, scope.object_id, scope.property_name, scope.change_value, __import__("json").dumps(scope.preserve, ensure_ascii=False), now()),
    )
    return fetch_one("SELECT * FROM constraints WHERE id=?", (edit_id,))

@router.get("/{project_id}/edits")
def list_edits(project_id: str):
    return fetch_all("SELECT * FROM constraints WHERE project_id=? ORDER BY created_at DESC", (project_id,))
