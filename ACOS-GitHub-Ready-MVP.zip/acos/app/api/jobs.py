from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from ..db import execute, fetch_one, fetch_all
from ..engines.workflow import run_mock_translation
from ..utils import now, uid, json_dumps

router = APIRouter(prefix="/api/projects", tags=["jobs"])

class TranslationJob(BaseModel):
    text: str

@router.post("/{project_id}/jobs/translation")
def create_translation_job(project_id: str, data: TranslationJob):
    if not fetch_one("SELECT id FROM projects WHERE id=?", (project_id,)):
        raise HTTPException(404, "Project not found")

    job_id = uid("job_")
    ts = now()
    execute(
        "INSERT INTO jobs(id,project_id,job_type,status,progress,message,input_json,output_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
        (job_id, project_id, "translation", "running", 10, "Running glossary-first translation workflow", json_dumps({"text": data.text}), "{}", ts, ts),
    )

    result = run_mock_translation(project_id, data.text)

    execute(
        "UPDATE jobs SET status=?,progress=?,message=?,output_json=?,updated_at=? WHERE id=?",
        ("completed", 100, "Completed MVP workflow", json_dumps(result), now(), job_id),
    )
    return fetch_one("SELECT * FROM jobs WHERE id=?", (job_id,))

@router.get("/{project_id}/jobs")
def list_jobs(project_id: str):
    return fetch_all("SELECT * FROM jobs WHERE project_id=? ORDER BY created_at DESC", (project_id,))

@router.get("/{project_id}/jobs/{job_id}")
def get_job(project_id: str, job_id: str):
    job = fetch_one("SELECT * FROM jobs WHERE id=? AND project_id=?", (job_id, project_id))
    if not job:
        raise HTTPException(404, "Job not found")
    return job
