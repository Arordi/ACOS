from fastapi import APIRouter, UploadFile, File, HTTPException
from ..db import execute, fetch_one, fetch_all
from ..services.storage import asset_path
from ..utils import now, uid, sha256_bytes
import shutil

router = APIRouter(prefix="/api/projects", tags=["assets"])

@router.post("/{project_id}/assets")
async def upload_asset(project_id: str, file: UploadFile = File(...)):
    if not fetch_one("SELECT id FROM projects WHERE id=?", (project_id,)):
        raise HTTPException(404, "Project not found")
    data = await file.read()
    asset_id = uid("asset_")
    path = asset_path(project_id, asset_id, file.filename or "upload.bin")
    path.write_bytes(data)
    execute(
        "INSERT INTO assets(id,project_id,filename,path,content_type,size,sha256,created_at) VALUES(?,?,?,?,?,?,?,?)",
        (asset_id, project_id, file.filename or "upload.bin", str(path), file.content_type or "", len(data), sha256_bytes(data), now()),
    )
    return fetch_one("SELECT * FROM assets WHERE id=?", (asset_id,))

@router.get("/{project_id}/assets")
def list_assets(project_id: str):
    return fetch_all("SELECT * FROM assets WHERE project_id=? ORDER BY created_at DESC", (project_id,))
