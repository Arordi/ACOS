from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from ..db import fetch_one
from ..services.exporter import export_project
from ..config import STORAGE_PATH
from pathlib import Path

router = APIRouter(prefix="/api/projects", tags=["export"])

@router.get("/{project_id}/export")
def export(project_id: str):
    if not fetch_one("SELECT id FROM projects WHERE id=?", (project_id,)):
        raise HTTPException(404, "Project not found")
    out_dir = STORAGE_PATH / "exports"
    out_dir.mkdir(parents=True, exist_ok=True)
    safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in fetch_one("SELECT name FROM projects WHERE id=?", (project_id,))["name"])
    destination = out_dir / f"{safe_name}.acos.zip"
    export_project(project_id, destination)
    return FileResponse(destination, media_type="application/zip", filename=destination.name)
