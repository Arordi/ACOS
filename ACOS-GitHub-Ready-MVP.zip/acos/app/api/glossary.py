from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from ..db import execute, fetch_one, fetch_all
from ..utils import now, uid
from ..engines.glossary import terminology_check

router = APIRouter(prefix="/api/projects", tags=["glossary"])

class GlossaryTermCreate(BaseModel):
    source: str
    target: str
    term_type: str = "term"
    locked: bool = False
    notes: str = ""

class TextCheck(BaseModel):
    text: str

@router.post("/{project_id}/glossary")
def add_term(project_id: str, data: GlossaryTermCreate):
    if not fetch_one("SELECT id FROM projects WHERE id=?", (project_id,)):
        raise HTTPException(404, "Project not found")
    term_id = uid("term_")
    execute(
        "INSERT INTO glossary_terms(id,project_id,source,target,term_type,locked,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",
        (term_id, project_id, data.source, data.target, data.term_type, int(data.locked), data.notes, now()),
    )
    return fetch_one("SELECT * FROM glossary_terms WHERE id=?", (term_id,))

@router.get("/{project_id}/glossary")
def list_terms(project_id: str):
    return fetch_all("SELECT * FROM glossary_terms WHERE project_id=? ORDER BY source", (project_id,))

@router.post("/{project_id}/glossary/check")
def check_text(project_id: str, data: TextCheck):
    return terminology_check(project_id, data.text)
