from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from ..db import execute, fetch_one, fetch_all
from ..utils import now, uid

router = APIRouter(prefix="/api/projects", tags=["projects"])

class ProjectCreate(BaseModel):
    name: str
    description: str = ""

@router.post("")
def create_project(data: ProjectCreate):
    project_id = uid("proj_")
    timestamp = now()
    execute(
        "INSERT INTO projects(id,name,description,created_at,updated_at) VALUES(?,?,?,?,?)",
        (project_id, data.name, data.description, timestamp, timestamp),
    )
    return fetch_one("SELECT * FROM projects WHERE id=?", (project_id,))

@router.get("")
def list_projects():
    return fetch_all("SELECT * FROM projects ORDER BY created_at DESC")

@router.get("/{project_id}")
def get_project(project_id: str):
    project = fetch_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if not project:
        raise HTTPException(404, "Project not found")
    return project

@router.delete("/{project_id}")
def delete_project(project_id: str):
    project = fetch_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if not project:
        raise HTTPException(404, "Project not found")
    execute("DELETE FROM projects WHERE id=?", (project_id,))
    execute("DELETE FROM assets WHERE project_id=?", (project_id,))
    execute("DELETE FROM glossary_terms WHERE project_id=?", (project_id,))
    execute("DELETE FROM translation_memory WHERE project_id=?", (project_id,))
    execute("DELETE FROM jobs WHERE project_id=?", (project_id,))
    execute("DELETE FROM constraints WHERE project_id=?", (project_id,))
    return {"deleted": True, "project_id": project_id}
